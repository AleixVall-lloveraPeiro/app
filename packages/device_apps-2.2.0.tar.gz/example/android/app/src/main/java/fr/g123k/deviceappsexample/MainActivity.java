package fr.g123k.deviceappsexample;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
