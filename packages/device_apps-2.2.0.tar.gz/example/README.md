# device_apps_example

Demonstrates how to use the device_apps plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
