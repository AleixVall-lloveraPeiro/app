#import <Flutter/Flutter.h>

@interface DeviceAppsPlugin : NSObject<FlutterPlugin>
@end
